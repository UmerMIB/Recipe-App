class Test {
	main = () => {
		console.log('no other instructors got swagger like us');
	};
}
// test
const test = new Test();
test.main();
