import React, { useState } from 'react';

export default function Home(props) {
	return <div className="HomePage">Life is good Im great</div>;
}
