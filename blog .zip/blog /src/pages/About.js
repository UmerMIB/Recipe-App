import React, { useState } from 'react';

export default function About(props) {
	return (
		<div className="AboutPage">
			Welcome to Kellie's super awesome site. I am such a good coder. You will
			be amazed etc....
		</div>
	);
}
