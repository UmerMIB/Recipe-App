import React, { useState } from 'react';

export default function Contact(props) {
	return <div className="ContactPage">This is the {props.page} page</div>;
}
