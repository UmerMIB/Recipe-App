export const recipes = [
	{
		_id: 1,
		title: 'recepi1',
		body: 'body',
		image_url:
			'https://i2.wp.com/www.downshiftology.com/wp-content/uploads/2015/11/shakshuka-11.jpg',
		publisher: 'Natalia'
	},
	{
		_id: 2,
		title: 'recepi1',
		body: 'body',
		image_url:
			'https://i2.wp.com/www.downshiftology.com/wp-content/uploads/2015/11/shakshuka-11.jpg',
		publisher: 'Natalia'
	},
	{
		_id: 3,
		title: 'recepi1',
		body: 'body',
		image_url:
			'https://i2.wp.com/www.downshiftology.com/wp-content/uploads/2015/11/shakshuka-11.jpg',
		publisher: 'Natalia'
	}
];
