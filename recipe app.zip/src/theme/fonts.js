export const fontFamily ={
    title = 'sasns serif'
}